import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FrontBookkeeper61842 implements IFrontBookkeeper {
    public String updateFront(String[] news){
    	HashMap<String, LinkedList<String>> units = new HashMap<String, LinkedList<String>>();
    	HashMap<String, LinkedList<String>> soldiers = new HashMap<String, LinkedList<String>>();
    	HashMap<String, String> unitsConnections = new HashMap<String, String>();
    	String finalResult = "";
    	
    	for (int i = 0; i < news.length; ++i){
    		Pattern pattern1 = Pattern.compile("^(\\w+)");
    		Matcher matcher1 = pattern1.matcher(news[i]);
    		if (matcher1.find()){
    			if (matcher1.group(0) == "soldiers"){
    			
    			} 
    			else if(matcher1.group(0).equals("show")){
    				
    			String second = "";
    			int j;
    			for(j = 5; j < news[i].length() && news[i].charAt(j) != ' '; ++j){
    				second += (news[i]).charAt(j);
    			}
    			
    			if (j == news[i].length() || (news[i]).charAt(j + 1) == '#'){
    				if(units.containsKey(second) == true){
    					String result = "[";
    					for(String s: units.get(second)){
    						if (s.equals(units.get(second).getLast()) == true){
    							result += s;
    						}
    						else{
    							result += s + ", ";
    						}
    					}
    					finalResult += result + "]\n";
    				}
    				else{
    					finalResult += "No such unit!\n";
    				}
    			}
    			else{
    				String temp = "";
    			
    				for (j += 1; j < news[i].length(); ++j){
    					temp += (news[i]).charAt(j);
    				}
    				
    				if (soldiers.containsKey(temp) == true){
    					String result = "";
    					for(String s: soldiers.get(temp)){
    						if (s.equals(soldiers.get(temp).getLast()) == true){
    							result += s;
    						}
    						else{
    							result += s + ", ";
    						}
    					}
    					finalResult += result + "\n";
    				}
    			}
    		}
    		else{
    			String first = matcher1.group(0);
    			if((news[i]).charAt(first.length() + 1) == '='){
    				LinkedList<String> list = new LinkedList<String>();
    				LinkedList<String> listUnit = new LinkedList<String>();
    				
    				listUnit.add(first);
    				
    				int j = first.length() + 4;
    				while(j < news[i].length() && (news[i]).charAt(j) != ']')/* && (news[i]).charAt(j) != ' ')*/{
    					String temp = "";
    					
    					int p = j;
    					while((news[i]).charAt(p) != ',' && (news[i]).charAt(p) != ']'){
        						temp += (news[i]).charAt(p);
        					++p;
        				}
    					
    					if (j != p) j = p + 2;
    					else ++j;
    					
    					list.add(temp);
    					soldiers.put(temp, listUnit);
    				}
    				
    				units.put(first, list);
    			}
    			else{
    				String second = "";
    				
    				int j = first.length() + 13;
    				while(j != news[i].length() && (news[i]).charAt(j) != ' '){
    					second += (news[i]).charAt(j);
    					++j;
    				}
    				
    				if (j == news[i].length() || (news[i]).charAt(j + 1) == '#'){
    					if (units.get(second).size() == 1){
    						finalResult += "Unit cannot contain both a soldier and another unit!\n";
    					}
    						else{
    							if (unitsConnections.containsKey(first) == true){    								
    								LinkedList<String> tempFirst = units.get(first);
    								LinkedList<String> temp = new LinkedList<String>();
    								
    								for (int p = 0; p < units.get(unitsConnections.get(first)).size(); ++p){
    									if(units.get(unitsConnections.get(first)).get(p).equals(tempFirst.getFirst()) != true){
    										temp.add(units.get(unitsConnections.get(first)).get(p));
    									}
    									else{
    										p += tempFirst.size();
    									}
    								}
    								
    								for(String s: tempFirst){
    									if (soldiers.containsKey(s)){
    										soldiers.get(s).remove(unitsConnections.get(first));
    									}
    								}
    								
    								units.put(unitsConnections.get(first),temp);
    							}
    							
    							LinkedList<String> temp = units.get(second);
								
								temp.addAll(units.get(first));
								units.put(second, temp);	
								unitsConnections.put(first, second);
								
								for(String soldier : units.get(first)){
									soldiers.get(soldier).add(second);
								}
    						}
    					}
    				else{
    					j += 15;
    					String temp = "";
    					
    					while((news[i]).charAt(j) != ' '){
    						temp += (news[i]).charAt(j);
    						++j;
    					}
    					
    					if (units.get(second).size() == 1){
    						if (units.get(first).getLast().equals(temp)){
    							if (unitsConnections.containsKey(first) == true){    								
    								LinkedList<String> tempFirst = units.get(first);
    								LinkedList<String> t = new LinkedList<String>();
    								
    								for (int p = 0; p < units.get(unitsConnections.get(first)).size(); ++p){
    									if(units.get(unitsConnections.get(first)).get(p).equals(tempFirst.getFirst()) != true){
    										t.add(units.get(unitsConnections.get(first)).get(p));
    									}
    									else{
    										p += tempFirst.size();
    									}
    								}
    								
    								for(String s: tempFirst){
    									if (soldiers.containsKey(s)){
    										soldiers.get(s).remove(unitsConnections.get(first));
    									}
    								}
    								
    								units.put(unitsConnections.get(first),t);
    							}
    							
    							LinkedList<String> m = units.get(second);
    							
    							m.addAll(units.get(first));
    							units.put(first, m);	
    							unitsConnections.put(first, second);
    							
    							for(String soldier : units.get(first)){
    								soldiers.get(soldier).add(second);
    							}
    							
    							
    							
    							
    							
    							
    							
    							
    							//LinkedList<String> tempList = units.get(second);
        						
    							//tempList.addAll(units.get(first));
    							//units.put(second, tempList);
    						}
    						else{
    							finalResult += "Cannot insert after this soldier because he is not in the end of a unit at topmost level\n";
    							continue;
    						}
    					}
    					else{
    						if (unitsConnections.containsKey(first) == true){    								
								LinkedList<String> tempFirst = units.get(first);
								LinkedList<String> t = new LinkedList<String>();
								
								for (int p = 0; p < units.get(unitsConnections.get(first)).size(); ++p){
									if(units.get(unitsConnections.get(first)).get(p).equals(tempFirst.getFirst()) != true){
										t.add(units.get(unitsConnections.get(first)).get(p));
									}
									else{
										p += tempFirst.size();
									}
								}
								
								for(String s: tempFirst){
									if (soldiers.containsKey(s) == true){
										soldiers.get(s).remove(unitsConnections.get(first));
									}
								}
								
								units.put(unitsConnections.get(first),t);
							}
							
							
							
							for(String soldier : units.get(first)){
								soldiers.get(soldier).add(second);
							}
    						
    						
    						
    						
    						
    						
    						
    						
    						
    						int indexToAdd = 0;
    						
    						for(String s: units.get(second)){
    							if(s.equals(temp) == true){
    								break;
    							}
    							indexToAdd++;
    						}
    						
    						LinkedList<String> tempList = units.get(second);
    						tempList.addAll(++indexToAdd, units.get(first));
    						units.put(second, tempList);
    					}
    				}
    			}
    		}
    	}
    	}
    	return finalResult;
    }
}


